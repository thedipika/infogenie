import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SupressionrecordsRoutingModule } from './supressionrecords-routing.module';
import { SupressionrecordsComponent } from './supressionrecords.component';
import{    NgxPaginationModule} from 'ngx-pagination';    
// import{ Ng2SearchPipeModule} from 'ng2-search-filter'
// import { RecordsService } from '../../services/records.service';
import {FormsModule} from '@angular/forms'
import{ Ng2SearchPipeModule} from 'ng2-search-filter';
@NgModule({
  declarations: [SupressionrecordsComponent],
  imports: [
    CommonModule,
    SupressionrecordsRoutingModule,
    FormsModule,
    NgxPaginationModule,
    Ng2SearchPipeModule
    
  ],
  // providers:[RecordsService]
})
export class SupressionrecordsModule { }
