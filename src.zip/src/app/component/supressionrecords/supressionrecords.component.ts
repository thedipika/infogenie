import { Component, OnInit } from '@angular/core';
import { RecordsService } from '../../services/records.service';

@Component({
  selector: 'app-supressionrecords',
  templateUrl: './supressionrecords.component.html',
  styleUrls: ['./supressionrecords.component.scss']
})
export class SupressionrecordsComponent implements OnInit {
  searchText:string;
records =[];
  constructor(private _suppressionrecord: RecordsService) {
    this.records= _suppressionrecord.getAllrecords()
   }
  p: number = 1;  
  ngOnInit(): void {
  }

}
