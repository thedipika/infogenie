import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupressionrecordsComponent } from './supressionrecords.component';

describe('SupressionrecordsComponent', () => {
  let component: SupressionrecordsComponent;
  let fixture: ComponentFixture<SupressionrecordsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SupressionrecordsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SupressionrecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
