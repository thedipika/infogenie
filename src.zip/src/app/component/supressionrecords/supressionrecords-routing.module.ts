import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SupressionrecordsComponent } from './supressionrecords.component';

const routes: Routes = [{ path: '', component: SupressionrecordsComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SupressionrecordsRoutingModule { }
