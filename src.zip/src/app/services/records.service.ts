import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RecordsService {
  searchText:string;
getAllrecords(){
  return[{srno:1, listname:'already contacted name', modifiedon:'28- Apr-2020 - 12:39', modifiedby:'chris jericho', records:'0'},
  {srno:2, listname:'marketo leads', modifiedon: '25-feb-2020 - 14:20', modifiedby:'mark henry', records:7800},
  {srno:3, listname:'Do not Disturb', modifiedon: '18-Apr-2020 - 04:30', modifiedby:'john nick', records:3500},
{srno:4, listname:'already contacted', modifiedon:'11-Apr-2020 - 04:430', modifiedby:'Dwen samuel', records:3200},
{srno:5, listname:'already contacted name', modifiedon:'28- Apr-2020 - 12:39', modifiedby:'chris jericho', records:0},
  {srno:6, listname:'marketo leads', modifiedon: '25-feb-2020 - 14:20', modifiedby:'mark henry', records:7800},
  {srno:7, listname:'Do not Disturb', modifiedon: '18-Apr-2020 - 04:30', modifiedby:'john nick', records:3500},
{srno:8, listname:'already contacted', modifiedon:'11-Apr-2020 - 04:430', modifiedby:'Dwen samuel', records:3200}

]
}
  constructor() { }
}
